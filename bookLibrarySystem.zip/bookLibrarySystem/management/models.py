from django.db import models

# Create your models here.

class BookModel(models.Model):
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=100)
    isbn = models.CharField(max_length=20)
    publication_year = models.IntegerField()
    status_choices = (
        ('available', 'Available'),
        ('borrowed', 'Borrowed')
    )
    status = models.CharField(max_length=10, choices=status_choices, default='available')

    

class LibraryModel(models.Model):
    books = models.ManyToManyField(BookModel)
