# from django.test import TestCase
# from rest_framework.test import APIClient
# from rest_framework import status
# from .models import BookModel, LibraryModel
# # Create your tests here.

# class BookAPITest(TestCase):
#     def setUp(self):
#         self.client = APIClient()
#         self.book = BookModel.objects.create(title='Test Book', author='Test Author', isbn='1234567890123', publication_year=2020, status='available')

#     def test_get_books(self):
#         response = self.client.get('/books/')
#         self.assertEqual(response.status_code, status.HTTP_200_OK)

#     def test_create_book(self):
#         data = {'title': 'New Book', 'author': 'New Author', 'isbn': '9876543210987', 'publication_year': 2022, 'status': 'available'}
#         response = self.client.post('/books/', data)
#         self.assertEqual(response.status_code, status.HTTP_201_CREATED)
#         self.assertEqual(BookModel.objects.count(), 2)

#     # Add more test cases for other CRUD operations as needed