from rest_framework.views import APIView
from rest_framework.response import Response
from .models import BookModel, LibraryModel
from django.db.models import Q 
from rest_framework import viewsets
from .serializers import BookSerializer, LibrarySerializer
from rest_framework.decorators import action
from rest_framework import status


class BookViewSet(viewsets.ModelViewSet):
    queryset = BookModel.objects.all()
    serializer_class = BookSerializer

    @action(detail=True, methods=['delete'])
    def delete_book(self, request, pk=None):
        try:
            book = self.get_object()
            book.delete()
            return Response({'message': 'Book deleted'}, status=status.HTTP_204_NO_CONTENT)
        except BookModel.DoesNotExist:
            return Response({'error': 'Book not found'}, status=status.HTTP_404_NOT_FOUND)
    
class LibraryViewSet(viewsets.ModelViewSet):
    queryset = LibraryModel.objects.all()
    serializer_class = LibrarySerializer
    

    @action(detail=True, methods=['get'])
    def books(self, request, pk=None):
        try:
            library = self.get_object()
            books = library.books.all()
            serializer = BookSerializer(books, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
    @action(detail=True, methods=['post'])
    def update_book_status(self, request, pk=None):
        try:
            library = self.get_object()
            book_id = request.data.get('book_id')
            status_value = request.data.get('status')
            book = library.books.filter(id=book_id).first()
            if not book:
                return Response({'error': 'Book not found in the library.'}, status=status.HTTP_404_NOT_FOUND)
            book.status = status_value
            book.save()
            return Response({'message': 'Book status updated successfully.'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
    @action(detail=True, methods=['post'])
    def remove_books(self, request, pk=None):
        try:
            library = self.get_object()
            books_data = request.data.get('books', [])
            
            # Remove each book from the library
            for book_data in books_data:
                book_id = book_data.get('id')
                book = library.books.filter(pk=book_id).first()
                if book:
                    library.books.remove(book)
            
            # Serialize the updated library and return the response
            serializer = LibrarySerializer(library)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
class SearchBooks(APIView):
    def get(self, request):
        query = request.query_params.get('q', '')
        books = BookModel.objects.filter(
            Q(title__icontains=query) |
            Q(author__icontains=query) |
            Q(publication_year__icontains=query)
        )
        serializer = BookSerializer(books, many=True)
        return Response(serializer.data)