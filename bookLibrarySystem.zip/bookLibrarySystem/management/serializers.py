
from rest_framework import serializers
from .models import BookModel, LibraryModel

class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookModel
        fields = '__all__'

class LibrarySerializer(serializers.ModelSerializer):
    class Meta:
        model = LibraryModel
        fields = '__all__'