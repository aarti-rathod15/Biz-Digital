from django.contrib import admin
from .models import *
# Register your models here.



# @admin.register(BookModel)
# class BookModelAdmin(admin.ModelAdmin):
#     list_display = ["id","title","author","isbn","publication_year","status"]



# @admin.register(LibraryModel)
# class LibraryModelAdmin(admin.ModelAdmin):
    # list_display = ["id","books"]

class BookModelAdmin(admin.ModelAdmin):
    # Correct usage of list_display
    list_display = ["id","title","author","isbn","publication_year","status"]

admin.site.register(BookModel, BookModelAdmin)

class LibraryModelAdmin(admin.ModelAdmin):
    list_display = ('id', 'get_books_display')

    def get_books_display(self, obj):
        return ", ".join([book.title for book in obj.books.all()])

admin.site.register(LibraryModel, LibraryModelAdmin)